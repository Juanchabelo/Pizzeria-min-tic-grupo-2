using System;

namespace Pizzeria.App.Dominio
{
    public class Envio:Pago
    {
        public int Id {get; set;}
        public Boolean EstadoEnvio {get; set;}
        public Cliente Cliente {get; set;}
    }
}