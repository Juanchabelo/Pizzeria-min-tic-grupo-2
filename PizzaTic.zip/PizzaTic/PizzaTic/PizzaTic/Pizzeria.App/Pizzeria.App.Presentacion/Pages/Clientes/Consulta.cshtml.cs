using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Pizzeria.App.Persistencia;
using Pizzeria.App.Dominio;

namespace pizzeria.app.presentacion.pages
{
    public class ConsultaModel : PageModel
    {
        private readonly IRepositorioCliente _repoCliente;
        public IEnumerable<Cliente> listaCliente{get; set;}
        public ConsultaModel(IRepositorioCliente repoClientes){
            _repoCliente=repoClientes;
        }
        public void OnGet()
        {
            
            listaCliente= _repoCliente.ConsultarClientes();
        }
    }
}
