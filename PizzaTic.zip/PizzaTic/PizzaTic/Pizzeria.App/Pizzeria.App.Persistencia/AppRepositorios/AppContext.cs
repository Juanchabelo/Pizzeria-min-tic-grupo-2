using Microsoft.EntityFrameworkCore;
using Pizzeria.App.Dominio;

namespace Pizzeria.App.Persistencia
{
    public class AppContext:DbContext
    {
        public DbSet<CarritoCompras> Carrito {get; set;}
        public DbSet<Cliente> Clientes {get; set;}
        public DbSet<Envio> Envios {get; set;}
        public DbSet<HistorialPedido> Historial {get; set;}
        public DbSet<Ingredientes> Ingrediente {get; set;}
        public DbSet<Pago> Pagos {get; set;}
        public DbSet<Producto> Productos {get; set;}

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if(!optionsBuilder.IsConfigured){
                optionsBuilder.UseSqlServer("Data Source = (localdb)\\MSSQLLocalDB; Initial Catalog=PizzeriaEq2");
            }
        }
    }
}