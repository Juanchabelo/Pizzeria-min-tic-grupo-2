using System;
using System.Collections.Generic;

namespace Pizzeria.App.Dominio
{
    public class HistorialPedido
    {
        public int Id {get; set;}
        public List<CarritoCompras> Historial { get; set;}
    }
}