using System;

namespace Pizzeria.App.Dominio
{
    public class CarritoCompras:Producto
    {
    public int Id {get; set;}
    public DateTime FechaCreacion {get; set;}

    }


}