using System;

namespace Pizzeria.App.Dominio
{
    public class Producto
    {
        public int Id {get; set;}
        public string NombreProducto {get; set;}
        public int CantidadProducto {get; set;}
        public float PrecioProducto {get; set;}
        public Ingredientes Ingredientes {get; set;}
    }

}