using Pizzeria.App.Dominio;
using System.Collections.Generic;
using System.Linq;

namespace Pizzeria.App.Persistencia
{
    public class RepositorioCliente:IRepositorioCliente
    {
        private readonly AppContext _appContext=new AppContext();
       
        public Cliente CrearCliente(Cliente cliente)
        {
            var clienteAdicionado = _appContext.Clientes.Add(cliente);
            _appContext.SaveChanges();
            return clienteAdicionado.Entity;
        }

        public Cliente ConsultarCliente(int idCliente)
        {
            var clienteEncontrado = _appContext.Clientes.FirstOrDefault(c=>c.Id ==idCliente);
            return clienteEncontrado;
        }

        public IEnumerable<Cliente> ConsultarClientes()
        {
            return _appContext.Clientes;
        }

        public Cliente ActualizarCliente(Cliente cliente)
        {
            var clienteEncontrado = _appContext.Clientes.FirstOrDefault(c=>c.Id ==cliente.Id);
            if (clienteEncontrado!=null){
                clienteEncontrado.PrimerNombre = cliente.PrimerNombre;
                clienteEncontrado.SegundoNombre = cliente.SegundoNombre;
                clienteEncontrado.PrimerApellido = cliente.PrimerApellido;
                clienteEncontrado.SegundoApellido = cliente.SegundoApellido;
                clienteEncontrado.Direccion = cliente.Direccion;
                clienteEncontrado.Telefono = cliente.Telefono;
                clienteEncontrado.Correo = cliente.Correo;

                _appContext.SaveChanges();

            }
            return clienteEncontrado;
        }

        public void EliminarCliente(int idCliente)
        {
            var clienteEncontrado = _appContext.Clientes.FirstOrDefault(c=>c.Id ==idCliente);
            if (clienteEncontrado==null)
            return;
            _appContext.Clientes.Remove(clienteEncontrado);
            _appContext.SaveChanges();
        }


    }
}