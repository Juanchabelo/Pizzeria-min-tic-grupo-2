using System;

namespace Pizzeria.App.Dominio
{
    public class Pago:CarritoCompras
    {
        public int Id {get; set;}
        public DateTime FechaPago {get; set;}
        public string MetodoPago {get; set;}
        public float TotalPago {get; set;}

    }

}