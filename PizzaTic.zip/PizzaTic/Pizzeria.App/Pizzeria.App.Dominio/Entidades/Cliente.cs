using System;
using System.ComponentModel.DataAnnotations;

namespace Pizzeria.App.Dominio
{
    public class Cliente
    {
        public int Id {get; set;}
        [Required]
        public string PrimerNombre {get; set;}
        [Required]
        public string SegundoNombre {get; set;}
        public string PrimerApellido {get; set;}
        [Required]
        public string SegundoApellido {get; set;}
        public string Direccion {get; set;}
        [Required]
        public string Telefono {get; set;}
        [Required]
        public string Correo {get; set;}
    }
}