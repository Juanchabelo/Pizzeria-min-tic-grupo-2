using System;

namespace Pizzeria.App.Dominio
{
    public class Ingredientes
    {
        public int Id {get; set;}
        public string NombreIngrediente {get; set;}
        public float Cantidad {get; set;}
    }
}