using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Pizzeria.App.Dominio;
using Pizzeria.App.Persistencia;

namespace Pizzeria.App.Presentacion.Pages
{
    public class RegistroModel : PageModel
    {
        private readonly IRepositorioCliente _repoCliente;
        public RegistroModel(IRepositorioCliente repoCliente)
        {
            _repoCliente=repoCliente;
        }
        [BindProperty]
        public Cliente cliente {get;set;}
        public void OnGet()
        {
        }

        public async Task<IActionResult> OnPost()
        {
            if(!ModelState.IsValid){
                return Page();
            }
            _repoCliente.CrearCliente(cliente);
            return RedirectToPage("/Index");
        }
    }
}
