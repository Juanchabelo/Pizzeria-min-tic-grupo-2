using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace pizzeria.app.presentacion.pages
{
    public class ProductosModel : PageModel
    {
        private string[] productos ={"pizza","Perros Calientes","Hamburguesas","bebidas"};
        public List<string> listaProductos {get;set;}
        public void OnGet()
        {
           listaProductos = new List<string>();
           listaProductos.AddRange(productos); 
        }
    }
}
