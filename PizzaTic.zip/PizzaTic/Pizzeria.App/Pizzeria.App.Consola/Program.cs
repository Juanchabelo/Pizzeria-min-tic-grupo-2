﻿using System;
using Pizzeria.App.Dominio;
using Pizzeria.App.Persistencia;


namespace Pizzeria.App.Consola
{
    class Program
    {
        private static IRepositorioCliente _repoCliente = new RepositorioCliente(new Persistencia.AppContext());
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            CrearCliente();
        }

        private static void CrearCliente()
        {
            var cliente=new Cliente
            {
                PrimerNombre="Maria",
                SegundoNombre="Gladys",
                PrimerApellido="Lopez",
                SegundoApellido="Gomez",
                Direccion="Calle 5 # 3-22",
                Telefono="315873255",
                Correo="maria@gmail.com",
            };
            _repoCliente.CrearCliente(cliente);
        }
    }
}
